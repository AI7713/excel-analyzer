import streamlit as st
import pandas as pd
from io import BytesIO
from openai import OpenAI

st.set_page_config(page_title="Excel Анализатор GPT", layout="centered")

st.title("📊 Excel Анализатор с помощью GPT-4")
st.write("Загрузите таблицу — получите текстовый анализ и новый Excel-файл с результатом.")

uploaded_file = st.file_uploader("📥 Загрузите Excel-файл", type=["xlsx"])

if uploaded_file:
    df = pd.read_excel(uploaded_file)

    st.subheader("📄 Предпросмотр данных:")
    st.dataframe(df.head())

    if st.button("🔍 Сделать анализ"):
        # Преобразуем в CSV для передачи GPT
        csv_data = df.to_csv(index=False)

        prompt = (
            "Ты — аналитик данных. Вот таблица в формате CSV:\n\n"
            f"{csv_data}\n\n"
            "Сделай краткий и полезный анализ: выяви тренды, закономерности, проблемы или гипотезы. Пиши по существу."
        )

        # Инициализация клиента
        client = OpenAI(api_key=st.secrets["OPENAI_API_KEY"])

        try:
            response = client.chat.completions.create(
                model="gpt-4",
                messages=[{"role": "user", "content": prompt}]
            )
            analysis = response.choices[0].message.content

            st.subheader("🧠 Результат анализа GPT:")
            st.write(analysis)

            # Запись в новый Excel-файл
            output = BytesIO()
            with pd.ExcelWriter(output, engine="openpyxl") as writer:
                df.to_excel(writer, index=False, sheet_name="Данные")
                pd.DataFrame([{"GPT-анализ": analysis}]).to_excel(writer, index=False, sheet_name="Вывод")

            st.download_button(
                label="💾 Скачать таблицу с анализом",
                data=output.getvalue(),
                file_name="gpt_analysis.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            )

        except Exception as e:
            st.error(f"❌ Ошибка анализа: {e}")
